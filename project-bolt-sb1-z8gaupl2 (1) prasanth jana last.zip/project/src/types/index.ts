export interface AnalysisResult {
  id: string;
  text: string;
  credibilityScore: number;
  timestamp: Date;
  factorsBreakdown: FactorBreakdown[];
  summary: string;
}

export interface FactorBreakdown {
  factor: string;
  score: number;
  explanation: string;
}

export type CredibilityLevel = 'high' | 'medium' | 'low' | 'unreliable';

export function getCredibilityLevel(score: number): CredibilityLevel {
  if (score >= 80) return 'high';
  if (score >= 60) return 'medium';
  if (score >= 40) return 'low';
  return 'unreliable';
}