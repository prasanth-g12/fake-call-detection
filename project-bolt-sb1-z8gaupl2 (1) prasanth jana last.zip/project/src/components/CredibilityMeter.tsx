import React from 'react';
import { AlertTriangle, CheckCircle, HelpCircle, Info } from 'lucide-react';
import { getCredibilityColor, getCredibilityText } from '../utils/analysisUtils';
import { CredibilityLevel, getCredibilityLevel } from '../types';

interface CredibilityMeterProps {
  score: number;
}

export default function CredibilityMeter({ score }: CredibilityMeterProps) {
  const credibilityColor = getCredibilityColor(score);
  const credibilityText = getCredibilityText(score);
  const level = getCredibilityLevel(score);
  
  const getIcon = (level: CredibilityLevel) => {
    switch (level) {
      case 'high':
        return <CheckCircle className="w-8 h-8 text-emerald-500" />;
      case 'medium':
        return <Info className="w-8 h-8 text-sky-500" />;
      case 'low':
        return <AlertTriangle className="w-8 h-8 text-amber-500" />;
      case 'unreliable':
        return <AlertTriangle className="w-8 h-8 text-red-500" />;
      default:
        return <HelpCircle className="w-8 h-8 text-gray-500" />;
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="flex flex-col items-center mb-2">
        {getIcon(level)}
        <h3 className="text-lg font-medium mt-2">{credibilityText}</h3>
      </div>
      
      <div className="w-full h-6 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full ${credibilityColor} transition-all duration-1000 ease-out`}
          style={{ width: `${score}%` }}
        />
      </div>
      
      <div className="w-full flex justify-between mt-1 text-xs text-gray-500">
        <span>Unreliable</span>
        <span>Low</span>
        <span>Medium</span>
        <span>High</span>
      </div>
      
      <div className="mt-4 flex justify-center">
        <span className="text-2xl font-bold">{score}</span>
        <span className="text-sm self-end mb-1 ml-0.5">/100</span>
      </div>
    </div>
  );
}