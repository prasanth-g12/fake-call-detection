import React from 'react';
import { Clock, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { useAnalysis } from '../context/AnalysisContext';
import { getCredibilityLevel } from '../types';

export default function HistoryList() {
  const { history, setCurrentAnalysis } = useAnalysis();

  const getIcon = (score: number) => {
    const level = getCredibilityLevel(score);
    
    switch (level) {
      case 'high':
        return <CheckCircle className="w-5 h-5 text-emerald-500" />;
      case 'medium':
        return <Info className="w-5 h-5 text-sky-500" />;
      case 'low':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'unreliable':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default:
        return null;
    }
  };

  if (history.length === 0) {
    return (
      <div className="w-full max-w-3xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center gap-2">
          <Clock className="h-5 w-5 text-indigo-700" />
          <h2 className="text-lg font-medium text-indigo-900">Analysis History</h2>
        </div>
        
        <div className="p-6 text-center text-gray-500">
          <p>No analysis history yet. Analyze some content to see it here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center gap-2">
        <Clock className="h-5 w-5 text-indigo-700" />
        <h2 className="text-lg font-medium text-indigo-900">Analysis History</h2>
      </div>
      
      <div className="divide-y divide-gray-100">
        {history.map((item) => {
          const truncatedText = item.text.length > 70 
            ? item.text.substring(0, 70) + '...' 
            : item.text;
            
          return (
            <button
              key={item.id}
              className="w-full text-left p-4 hover:bg-gray-50 transition-colors flex items-start"
              onClick={() => setCurrentAnalysis(item)}
            >
              <div className="mr-3 mt-1 flex-shrink-0">
                {getIcon(item.credibilityScore)}
              </div>
              
              <div className="flex-grow">
                <p className="text-gray-700 mb-1">{truncatedText}</p>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">
                    {new Date(item.timestamp).toLocaleString()}
                  </span>
                  
                  <span className="text-sm font-medium">
                    Score: {item.credibilityScore}/100
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}