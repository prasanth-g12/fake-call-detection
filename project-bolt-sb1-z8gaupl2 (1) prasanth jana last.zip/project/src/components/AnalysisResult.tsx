import React from 'react';
import { AnalysisResult as AnalysisResultType } from '../types';
import CredibilityMeter from './CredibilityMeter';
import FactorsBreakdown from './FactorsBreakdown';
import { ArrowLeft, AlertTriangle, Lightbulb } from 'lucide-react';
import { useAnalysis } from '../context/AnalysisContext';

export default function AnalysisResult() {
  const { currentAnalysis, setCurrentAnalysis } = useAnalysis();
  
  if (!currentAnalysis) return null;
  
  const { credibilityScore, factorsBreakdown, summary, text } = currentAnalysis;
  
  const handleBack = () => {
    setCurrentAnalysis(null);
  };
  
  const truncatedText = text.length > 150 
    ? text.substring(0, 150) + '...' 
    : text;

  return (
    <div className="w-full max-w-3xl mx-auto">
      <button 
        onClick={handleBack}
        className="flex items-center text-indigo-600 hover:text-indigo-800 transition-colors mb-4"
      >
        <ArrowLeft className="w-4 h-4 mr-1" />
        Back to analysis
      </button>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-indigo-50 border-b border-indigo-100">
          <h2 className="text-lg font-medium text-indigo-900">Analysis Results</h2>
        </div>
        
        <div className="p-6">
          <div className="p-4 bg-gray-50 rounded-lg mb-6">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Analyzed Content</h3>
            <p className="text-gray-700">{truncatedText}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <CredibilityMeter score={credibilityScore} />
            
            <div className="bg-gray-50 p-4 rounded-lg flex items-start">
              <div className="mr-3 mt-0.5">
                <Lightbulb className="w-5 h-5 text-amber-500" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-1">Summary</h3>
                <p className="text-sm text-gray-600">{summary}</p>
              </div>
            </div>
          </div>
          
          <FactorsBreakdown factors={factorsBreakdown} />
          
          <div className="mt-8 p-4 bg-amber-50 border border-amber-100 rounded-lg flex items-start">
            <AlertTriangle className="w-5 h-5 text-amber-500 mr-3 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-amber-800">
              This analysis is for educational purposes only and should not be the sole determinant of content credibility. 
              Always cross-reference information with trusted sources and apply critical thinking skills.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}