import React from 'react';
import { FactorBreakdown } from '../types';
import { getCredibilityColor } from '../utils/analysisUtils';

interface FactorsBreakdownProps {
  factors: FactorBreakdown[];
}

export default function FactorsBreakdown({ factors }: FactorsBreakdownProps) {
  return (
    <div className="w-full">
      <h3 className="text-lg font-medium mb-4">Analysis Factors</h3>
      
      <div className="space-y-4">
        {factors.map((factor, index) => (
          <div key={index} className="animate-fadeIn" style={{ animationDelay: `${index * 150}ms` }}>
            <div className="flex justify-between mb-1">
              <span className="font-medium text-gray-700">{factor.factor}</span>
              <span className="font-medium">{factor.score}/100</span>
            </div>
            
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`h-full ${getCredibilityColor(factor.score)} transition-all duration-1000 ease-out`}
                style={{ width: `${factor.score}%` }}
              />
            </div>
            
            <p className="text-sm text-gray-600 mt-1">{factor.explanation}</p>
          </div>
        ))}
      </div>
    </div>
  );
}