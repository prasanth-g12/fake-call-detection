import React from 'react';
import { AlignRight, Shield } from 'lucide-react';

interface HeaderProps {
  setActiveTab: (tab: string) => void;
  activeTab: string;
}

export default function Header({ setActiveTab, activeTab }: HeaderProps) {
  const tabs = [
    { id: 'analyze', label: 'Analyze' },
    { id: 'results', label: 'Results' },
    { id: 'history', label: 'History' },
    { id: 'education', label: 'Education' }
  ];
  
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  
  return (
    <header className="bg-gradient-to-r from-indigo-900 to-indigo-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8" />
            <div>
              <h1 className="text-2xl font-bold">TruthGuard</h1>
              <p className="text-xs text-indigo-200">Advanced Fake News Detection</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white text-indigo-900 font-medium'
                    : 'text-white hover:bg-indigo-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <AlignRight className="h-6 w-6" />
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="mt-4 md:hidden flex flex-col space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white text-indigo-900 font-medium'
                    : 'text-white hover:bg-indigo-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}