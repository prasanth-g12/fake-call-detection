import React from 'react';
import InfoCard from './InfoCard';
import { Lightbulb } from 'lucide-react';

export default function EducationalResources() {
  return (
    <div className="w-full max-w-3xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center gap-2">
        <Lightbulb className="h-5 w-5 text-indigo-700" />
        <h2 className="text-lg font-medium text-indigo-900">Fake News Education</h2>
      </div>
      
      <div className="p-6">
        <p className="text-gray-600 mb-6">
          Understanding how to identify fake news is an essential skill in today's information landscape.
          Here are key concepts and strategies to help you evaluate content reliability.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoCard 
            icon="alert"
            title="Common Red Flags"
            description="Watch for sensationalist language, excessive use of ALL CAPS, multiple exclamation points, and claims that seem too extreme or simplified."
          />
          
          <InfoCard 
            icon="check"
            title="Source Verification"
            description="Check the website's URL, about page, and reputation. Look for established news sources with editorial standards and fact-checking processes."
          />
          
          <InfoCard 
            icon="share"
            title="Cross-Reference Information"
            description="Verify claims across multiple reputable sources. If a story is significant, it should be reported by several established news outlets."
          />
          
          <InfoCard 
            icon="book"
            title="Check Publish Dates"
            description="Old articles recirculated out of context can mislead. Always check when content was published and whether it's still relevant."
          />
        </div>
        
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-md font-medium text-gray-800 mb-2">Critical Thinking Questions</h3>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-start">
              <span className="inline-block w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs mr-2 mt-1">1</span>
              <span>Who created this content and what is their expertise?</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs mr-2 mt-1">2</span>
              <span>What evidence is provided to support the claims?</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs mr-2 mt-1">3</span>
              <span>What might be missing from this story?</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs mr-2 mt-1">4</span>
              <span>Who benefits or profits from this information?</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs mr-2 mt-1">5</span>
              <span>How does this information make you feel? Is it designed to provoke emotion?</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}