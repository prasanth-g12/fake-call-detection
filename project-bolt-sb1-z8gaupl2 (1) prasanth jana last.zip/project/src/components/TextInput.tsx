import React, { useState } from 'react';
import { Newspaper, Search } from 'lucide-react';
import { analyzeText } from '../utils/analysisUtils';
import { useAnalysis } from '../context/AnalysisContext';

export default function TextInput() {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { setCurrentAnalysis, addToHistory } = useAnalysis();

  const handleAnalyze = async () => {
    if (!text.trim() || isAnalyzing) return;
    
    setIsAnalyzing(true);
    try {
      const result = await analyzeText(text);
      setCurrentAnalysis(result);
      addToHistory(result);
    } catch (error) {
      console.error('Analysis failed:', error);
      // In a real app, we would show an error message to the user
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-white rounded-lg shadow-md overflow-hidden transition-all">
      <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center gap-2">
        <Newspaper className="h-5 w-5 text-indigo-700" />
        <h2 className="text-lg font-medium text-indigo-900">Analyze Content</h2>
      </div>
      
      <div className="p-6">
        <textarea
          className="w-full h-48 p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none transition"
          placeholder="Paste news article or content to analyze..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={isAnalyzing}
        />
        
        <div className="mt-4 flex justify-end">
          <button
            className={`px-6 py-2 rounded-lg font-medium flex items-center gap-2 ${
              isAnalyzing || !text.trim()
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                : 'bg-indigo-600 text-white hover:bg-indigo-700 transition-colors'
            }`}
            onClick={handleAnalyze}
            disabled={isAnalyzing || !text.trim()}
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Analyze</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}