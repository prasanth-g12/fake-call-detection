import React from 'react';
import { BookOpen, AlertTriangle, Share2, CheckCircle } from 'lucide-react';

interface InfoCardProps {
  title: string;
  description: string;
  icon: 'book' | 'alert' | 'share' | 'check';
}

export default function InfoCard({ title, description, icon }: InfoCardProps) {
  const getIcon = () => {
    switch (icon) {
      case 'book':
        return <BookOpen className="h-6 w-6 text-indigo-600" />;
      case 'alert':
        return <AlertTriangle className="h-6 w-6 text-amber-500" />;
      case 'share':
        return <Share2 className="h-6 w-6 text-sky-500" />;
      case 'check':
        return <CheckCircle className="h-6 w-6 text-emerald-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center mb-4">
        {getIcon()}
        <h3 className="ml-2 text-lg font-medium text-gray-800">{title}</h3>
      </div>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}