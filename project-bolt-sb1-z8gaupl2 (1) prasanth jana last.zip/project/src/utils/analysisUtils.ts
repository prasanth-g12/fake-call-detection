import { AnalysisResult, FactorBreakdown } from '../types';

// These are simulated analysis methods - in a real app, these would connect to a proper NLP service
export const analyzeText = (text: string): Promise<AnalysisResult> => {
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      const id = Math.random().toString(36).substring(2, 9);
      
      // Calculate a random credibility score for demo purposes
      const credibilityScore = Math.floor(Math.random() * 100);
      
      // Generate simulated factor breakdown
      const factorsBreakdown: FactorBreakdown[] = [
        {
          factor: 'Source Credibility',
          score: Math.floor(Math.random() * 100),
          explanation: 'Analysis of the source reputation and reliability based on historical accuracy.'
        },
        {
          factor: 'Emotional Language',
          score: Math.floor(Math.random() * 100),
          explanation: 'Measurement of emotional or sensationalist language that may indicate bias.'
        },
        {
          factor: 'Fact Consistency',
          score: Math.floor(Math.random() * 100),
          explanation: 'Evaluation of internal consistency and alignment with verified facts.'
        },
        {
          factor: 'Citation Quality',
          score: Math.floor(Math.random() * 100),
          explanation: 'Assessment of sources cited and whether claims are properly attributed.'
        },
        {
          factor: 'Writing Style',
          score: Math.floor(Math.random() * 100),
          explanation: 'Analysis of writing style patterns associated with credible reporting.'
        }
      ];
      
      let summary = '';
      if (credibilityScore >= 80) {
        summary = 'This content appears to be highly credible based on our analysis. It contains balanced reporting, proper citations, and minimal sensationalist language.';
      } else if (credibilityScore >= 60) {
        summary = 'This content has moderate credibility. While generally factual, there may be some issues with bias, incomplete context, or emotional language.';
      } else if (credibilityScore >= 40) {
        summary = 'This content shows several warning signs of potential misinformation. Exercise caution and verify with additional sources.';
      } else {
        summary = 'This content displays multiple characteristics of unreliable information. Strong emotional language, lack of citations, and factual inconsistencies detected.';
      }
      
      resolve({
        id,
        text,
        credibilityScore,
        timestamp: new Date(),
        factorsBreakdown,
        summary
      });
    }, 1500);
  });
};

// Utility to get credibility color based on score
export const getCredibilityColor = (score: number): string => {
  if (score >= 80) return 'bg-emerald-500';
  if (score >= 60) return 'bg-sky-500';
  if (score >= 40) return 'bg-amber-500';
  return 'bg-red-500';
};

// Utility to get credibility text based on score
export const getCredibilityText = (score: number): string => {
  if (score >= 80) return 'Highly Credible';
  if (score >= 60) return 'Moderately Credible';
  if (score >= 40) return 'Low Credibility';
  return 'Unreliable';
};