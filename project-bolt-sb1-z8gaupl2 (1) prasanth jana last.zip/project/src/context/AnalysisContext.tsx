import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AnalysisResult } from '../types';

interface AnalysisContextType {
  history: AnalysisResult[];
  currentAnalysis: AnalysisResult | null;
  setCurrentAnalysis: (analysis: AnalysisResult | null) => void;
  addToHistory: (analysis: AnalysisResult) => void;
  clearHistory: () => void;
}

const AnalysisContext = createContext<AnalysisContextType | undefined>(undefined);

export function AnalysisProvider({ children }: { children: ReactNode }) {
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(null);

  const addToHistory = (analysis: AnalysisResult) => {
    setHistory((prev) => [analysis, ...prev]);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <AnalysisContext.Provider
      value={{
        history,
        currentAnalysis,
        setCurrentAnalysis,
        addToHistory,
        clearHistory
      }}
    >
      {children}
    </AnalysisContext.Provider>
  );
}

export function useAnalysis() {
  const context = useContext(AnalysisContext);
  if (context === undefined) {
    throw new Error('useAnalysis must be used within an AnalysisProvider');
  }
  return context;
}